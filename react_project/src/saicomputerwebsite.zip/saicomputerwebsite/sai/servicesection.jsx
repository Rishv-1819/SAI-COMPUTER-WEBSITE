import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../css/servicesection.css";

const services = [
  {
    title: "AMISP",
    description:
      "SCL provides end-to-end AMI solutions, transforming utilities with smart metering, connectivity, and analytics. Used by nine Discoms, its AI-driven tools enhance billing, payment prediction, exception detection, and revenue monitoring."
  },
  {
    title: "Smart Metering",
    description:
      "Advanced smart metering solutions with real-time monitoring, energy analytics, and automated reporting."
  },
  {
    title: "IoT Solutions",
    description:
      "Modern IoT connectivity solutions for industrial automation, data collection, and remote monitoring."
  },
  {
    title: "Analytics",
    description:
      "AI-powered analytics dashboard for business intelligence, forecasting, and operational efficiency."
  }
];

function Services() {
  const [active, setActive] = useState(0);

  const nextService = () => {
    setActive((prev) => (prev + 1) % services.length);
  };

  const prevService = () => {
    setActive((prev) =>
      prev === 0 ? services.length - 1 : prev - 1
    );
  };

  return (
    <section className="services-section">

      <div className="container">

        <h1 className="main-title">
          Uninterrupted Power, Seamless Solution
        </h1>

        <div className="service-navigation">

          <button onClick={prevService} className="nav-btn">
            &#8592;
          </button>

          <div className="service-heading">
            Services
          </div>

          <button onClick={nextService} className="nav-btn">
            &#8594;
          </button>

        </div>

        <div className="tabs-row">

          {services.map((service, index) => (
            <button
              key={index}
              className={`tab-btn ${
                active === index ? "active" : ""
              }`}
              onClick={() => setActive(index)}
            >
              {service.title}
            </button>
          ))}

        </div>

        <div className="service-card">

          <h2>{services[active].title}</h2>

          <p>{services[active].description}</p>

          <Link
            to={`/services/${services[active].title.toLowerCase()}`}
            className="read-more"
          >
            Read More →
          </Link>

        </div>

      </div>

    </section>
  );
}

export default Services;