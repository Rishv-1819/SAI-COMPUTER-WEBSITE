import React from "react";
import "../css/vertical.css";
import { Link } from "react-router-dom";

const Vertical = () => {
  return (
    <section className="verticals">
      <span className="badge">OUR VERTICALS</span>

      <h1 className="heading">
        Innovative Energy Solutions for a Sustainable Future
      </h1>

      <div className="cards">
        <div className="card">
          <div className="card-content">
            <h3>Transformer Manufacturing</h3>
            <p>
              Industry-leading transformer manufacturing solutions
              with high performance, reliability and innovation
              for modern energy infrastructure.
            </p>
          </div>

          <div className="card-footer">
            <a href="/">Visit Site →</a>
          </div>
        </div>

        <div className="card">
          <div className="card-content">
            <h3>Distribution Franchise</h3>
            <p>
              End-to-end distribution franchise services ensuring
              seamless power distribution, operational efficiency,
              and customer satisfaction.
            </p>
          </div>

          <Link to="/Read More" className="card-footer">
          Read More
          </Link>
        </div>

        <div className="card">
          <div className="card-content">
            <h3>Digital Products</h3>
            <p>
              Innovative software solutions designed specifically
              for power utilities to improve productivity,
              automation and customer experience.
            </p>
          </div>

          <Link to="/Read" className="card-footer">
          Read More
          </Link>
        </div>

        <div className="card">
          <div className="card-content">
            <h3>Utility Operations</h3>
            <p>
              Smart metering, billing, customer support and
              workforce management solutions for efficient
              utility operations.
            </p>
          </div>

          <Link to="/More" className="card-footer">
          Read More
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Vertical;