import React from "react";
import "../css/client.css";

import clientLogo from "/src/assets/UPCL-Recruitment-2023-1.png";

import logo1 from "/src/assets/images (1).jpg";
import logo2 from "/src/assets/EE4tDiPUYAAs9Iz.jpg";
import logo3 from "/src/assets/images (2).jpg";
import logo4 from "/src/assets/images (3).jpg";
import logo5 from "/src/assets/images.jpg";
import logo6 from "/src/assets/st-3.jpg";
import logo7 from "/src/assets/EE4tDiPUYAAs9Iz.jpg";
import logo8 from "/src/assets/images (1).jpg";
import logo9 from "/src/assets/images (2).jpg";
import logo10 from "/src/assets/EE4tDiPUYAAs9Iz.jpg";

const Client = () => {
  const logos = [
    logo1,
    logo2,
    logo3,
    logo4,
    logo5,
    logo6,
    logo7,
    logo8,
    logo9,
    logo10,
  ];

  return (
    <section className="clients-section">
      <div className="container">
        <h2 className="section-title">Our Clients</h2>

        <p className="section-subtitle">
          Trusted by Leading Organizations Across India
        </p>

        <div className="client-card">
          <div className="client-logo">
            <img src={clientLogo} alt="UPCL" />
          </div>

          <div className="client-info">
            <h3>Uttarakhand Power Corporation Ltd.</h3>

            <p>
              Providing reliable electricity distribution services
              throughout Uttarakhand. We support digital
              transformation and utility management solutions for
              better customer experiences.
            </p>

            <a href="#" className="btn">
              Learn More
            </a>
          </div>
        </div>

        <div className="logo-slider">
          <div className="logo-track">
            {logos.map((logo, index) => (
              <div className="logo-item" key={index}>
                <img src={logo} alt={`Logo ${index + 1}`} />
              </div>
            ))}

            {/* Duplicate for infinite scroll */}
            {logos.map((logo, index) => (
              <div className="logo-item" key={`duplicate-${index}`}>
                <img src={logo} alt={`Logo ${index + 1}`} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Client;