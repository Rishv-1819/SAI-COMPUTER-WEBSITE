import style from '../css/megamenu.module.css';
import { Link } from "react-router-dom";
import Distribution from "../../assets/solutionimage/Distribution.png";
import Transformer from "../../assets/solutionimage/Transformer.png";
import Transmission from "../../assets/solutionimage/transmission.png";
import Utility from "../../assets/solutionimage/Utility.png";

function MegaMenu() {
  return (
    <div className={style["mega-menu"]}>
      <div className={style["services-section"]}>
        <h2>Services</h2>

        <Link to="/amisp">AMISP</Link>

        <Link to="/smart-meter-analytics">
          Smart Meter Analytics
        </Link>

        <Link to="/revenue-management">
          Total Revenue Management
        </Link>

        <Link to="/predictive-maintenance">
          Predictive Maintenance
        </Link>

        <Link to="/outage-management-system">
          Outage Management System
        </Link>

        <Link to="/meter-verification-ocr">
          Meter Verification / OCR
        </Link>
      </div>

      <div className={style["verticals-section"]}>
        <h2>Our Verticals</h2>

        <div className={style["vertical-grid"]}>
          <Link to="/transformer-manufacturing" className={style["vertical-card"]}>
            <img src={Transformer} alt="" />
            <h3>Transformer Manufacturing</h3>
          </Link>

          <Link to="/distribution-franchise" className={style["vertical-card"]}>
            <img src={Distribution} alt="" />
            <h3>Distribution Franchise</h3>
          </Link>

          <Link to="/digital-product" className={style["vertical-card"]}>
            <img src={Transmission} alt="" />
            <h3>Digital Product</h3>
          </Link>

          <Link to="/utility-operations" className={style["vertical-card"]}>
            <img src={Utility} alt="" />
            <h3>Utility Operations</h3>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default MegaMenu;