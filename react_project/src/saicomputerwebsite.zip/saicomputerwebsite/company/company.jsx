import React from "react";
import { Link } from "react-router-dom";
import "../css/company.css";

const CompanyMenu = () => {
  return (
    <div className="company-menu">
      <div className="menu-container">
        <div className="menu-left">
          <h1>Seamless Solutions</h1>
        </div>

        <div className="menu-right">
          <Link to="/about-us">About Us</Link>

          <Link to="/why-us">Why Us</Link>

          <Link to="/careers">Careers</Link>

          <Link to="/investors">Investors</Link>
        </div>
      </div>
    </div>
  );
};

export default CompanyMenu;