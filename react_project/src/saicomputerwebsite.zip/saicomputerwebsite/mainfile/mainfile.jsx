//import Home from "../pages/home/home.jsx";
//import Header from "../components/header.jsx";
//import Footer from "../components/footer.jsx";
//import Blogs from "../pages/Blogs/Blogs.jsx";
//import Events from "../pages/Events and Gallery/Events.jsx";
//import Contact from "../pages/contact/contact.jsx";
//import CompanyMenu from "../company/company.jsx";
//import MegaMenu from "../Solution/megamenu.jsx";
//import DistributionFranchisee from "../pages/DistributionFranchisee/DistributionFranchisee.jsx";
//import DigitalProducts from "../pages/Digitalproducts/Digitalproducts.jsx";
//import { BrowserRouter, Routes,Route } from "react-router-dom";
const MainFile = () => {
  return( 
    <BrowserRouter>
    <Header/>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/Blogs" element={<Blogs/>}/>
      <Route path="/events" element={<Events/>}/>
      <Route path="/contact" element={<Contact/>}/>
      <Route path="/company" element={<CompanyMenu/>}/>
      <Route path="/solutions" element={<MegaMenu/>}/>
      <Route path="/Read more" element={<DistributionFranchisee/>}/>
      <Route path="/Read" element={<DigitalProducts/>}/>
    </Routes>
    <Footer/>
    </BrowserRouter>
  );
};

//export default MainFile;
