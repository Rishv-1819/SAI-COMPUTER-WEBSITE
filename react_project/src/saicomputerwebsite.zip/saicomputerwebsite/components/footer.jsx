import React from "react";
import "../css/Footer.css";

const Footer = () => {
  return (
    <footer>
      {/* Top Footer */}
      <div className="footer-top">
        <div className="footer-container">

          {/* Solutions */}
          <div className="footer-column">
            <h2>Solutions</h2>

            <div className="footer-links-grid">
              <div>
                <a href="/amisp">AMISP</a>
                <a href="/smart-meter-analytics">Smart Meter Analytics</a>
                <a href="/revenue-management">Total Revenue Management</a>
                <a href="/predictive-maintenance">Predictive Maintenance</a>
                <a href="/vigil-eye">Vigil Eye</a>
                <a href="/portfolio-management">Portfolio Management</a>
              </div>

              <div>
                <a href="/oms">Outage Management System</a>
                <a href="/ocr">Meter Verification & OCR</a>
                <a href="/customer-segmentation">Customer Segmentation</a>
                <a href="/energy-accounting">Energy Accounting</a>
                <a href="/payment-prediction">Payment Prediction</a>
              </div>
            </div>

            <h2 className="company-title">Company</h2>

            <div className="footer-links-grid">
              <div>
                <a href="/about">About us</a>
                <a href="/why-us">Why us</a>
                <a href="/consumer-portal">
                  Consumer Portal [Smriti Analysis]
                </a>
                <a href="/careers">Careers</a>
              </div>

              <div>
                <a href="/blogs">Blogs</a>
                <a href="/case-studies">Case Studies</a>
                <a href="/events">Events</a>
              </div>
            </div>
          </div>

          {/* Logo Section */}
          <div className="footer-logo-section">
            <div className="circle c1"></div>
            <div className="circle c2"></div>
            <div className="circle c3"></div>
            <div className="circle c4"></div>
            <div className="circle c5"></div>
            <div className="circle c6"></div>

            <div className="logo-box">
              <h1>SAI</h1>
              <p>Coming together for Success</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="footer-bottom">
        <div className="contact-info">
          <div>
            <p>
              Sai Dhaam, Victoria Park Meerut - 250001
              <br />
              Uttar Pradesh, India
            </p>
          </div>

          <div>
            <p>
              T:+91-9359611016
              <br />
              E:
              <a href="mailto:saicomp@thesaicomputers.com">
                saicomp@thesaicomputers.com
              </a>
            </p>
          </div>

          <div className="social-links">
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noreferrer"
            >
              LinkedIn
            </a>

            <a
              href="https://x.com"
              target="_blank"
              rel="noreferrer"
            >
              X
            </a>

            <a
              href="https://facebook.com"
              target="_blank"
              rel="noreferrer"
            >
              Facebook
            </a>
          </div>
        </div>

        <div className="copyright">
          <p>
            © 2025 Sai Computers Limited. All rights reserved.
          </p>

          <div className="policy-links">
            <a href="/terms">Terms & Conditions</a>
            <a href="/privacy-policy">Privacy Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;