import React from "react";
import "../css/header.css";
import Sailogo from "/src/assets/Sailogo.png";
import { Link } from "react-router-dom";

const Header = () => {
  return( 
      
    <nav className="navbar">

    <div className="logo">
        <img src={Sailogo} alt=""/>
    </div>

    <div className="nav-links">
        <Link to="/" className="active">
          Home
        </Link>

        <Link to="/solutions" className="dropdown">
          Solutions
        </Link>

        <Link to="/company" className="dropdown">
          Company
        </Link>

        <Link to="/Blogs">
          Blogs
        </Link>

        <Link to="/events">
          Events and Gallery
        </Link>
    </div>

    <Link to="/contact" className="contact-btn">
        Contact Us
      </Link>
</nav>
  );
};

export default Header;