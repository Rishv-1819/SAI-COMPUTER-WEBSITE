import Header from "../../components/header.jsx";
import Slider from "../../sai/slider.jsx";
import Client from "../../sai/client.jsx";
import Vertical from "../../sai/vertical.jsx";
import Servicesection from "../../sai/servicesection.jsx";
import Casestudies from "../../sai/casestudies.jsx";
import Footer from "../../components/footer.jsx";
//import { BrowserRouter } from "react-router-dom";

const Home = () => {
  return(
    <div>
      <Slider/>
      <Client/>
      <Vertical/>
      <Servicesection/>
      <Casestudies/>
    </div>
  );
};

export default Home;
