//import Header from "../../components/header.jsx";
//import Footer from "../../components/footer.jsx";
import Case from "../../sai/casestudies.jsx"
//import { BrowserRouter } from "react-router-dom";

function Blogs() {
    return(
        <>
        <Case/>
        </>
    )
}

export default Blogs;