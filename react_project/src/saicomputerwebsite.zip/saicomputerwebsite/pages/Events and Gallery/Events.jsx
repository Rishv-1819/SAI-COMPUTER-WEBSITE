import Header from "../../components/header.jsx";
import Footer from "../../components/footer.jsx";
import Event from "./route/Event2024.jsx";


function Events() {
    return(
        <>
        <Event/>
        </>
    )
}
export default Events;