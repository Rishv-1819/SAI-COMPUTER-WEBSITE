//import Header from "../../components/header.jsx";
//import Footer from "../../components/footer.jsx";
import ContactFront from "./router/front.jsx"
import Location from "./router/location.jsx"
import EnquiryForm from "./router/EnquiryForm.jsx"
function Contact() {
    return (
        <div>
            <ContactFront/>
            <Location/>
            <EnquiryForm/>
        </div>
    )
}
export default Contact;