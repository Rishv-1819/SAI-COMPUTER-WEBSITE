import React from "react";
import "../../../css/enquiry.css";

const ContactFront = () => {
  return (
    <section className="contact-section">
      <div className="contact-tag">CONTACT</div>

      <h1 className="contact-title">We're here to help</h1>

      <div className="contact-info">
        <div className="info-box">
          <h3>Call us at:</h3>
          <p>+91-9359611016</p>
        </div>

        <div className="divider"></div>

        <div className="info-box">
          <h3>Email us:</h3>
          <p>saicomp@thesaicomputers.com</p>
        </div>
      </div>

      <button className="contact-btn">
        Schedule consultation
      </button>

      <div className="pattern">
        {[...Array(25)].map((_, index) => (
          <span key={index}></span>
        ))}
      </div>
    </section>
  );
};

export default ContactFront;