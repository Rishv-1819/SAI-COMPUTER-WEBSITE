import React from "react";
import "../../../css/enquiry.css";
import BuildingImg from "../../../../assets/Building.jpg"; // Add your image here

const Location = () => {
  return (
    <section className="location-section">
      {/* Decorative Pattern */}
      <div className="location-pattern">
        {[...Array(36)].map((_, index) => (
          <span key={index}></span>
        ))}
      </div>

      <div className="container">
        <h1 className="location-title">Our Location</h1>

        <div className="location-content">
          {/* Left Content */}
          <div className="location-info">
            <h2>Sai Computers Limited</h2>

            <h3>Meerut</h3>

            <p>
              Sai Dhaam, Victoria Park
              <br />
              Meerut - 250001 Uttar
              <br />
              Pradesh, India
            </p>

            <p className="phone">+91-9359611016</p>

            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="direction-btn"
            >
              Get direction
            </a>
          </div>

          {/* Right Image */}
          <div className="location-image">
            <img src={BuildingImg} alt="Sai Computers Office" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Location;