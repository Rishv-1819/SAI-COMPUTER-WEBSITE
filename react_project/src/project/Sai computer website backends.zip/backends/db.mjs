import mysql from "mysql2/promise";
import { log } from "node:console";
//import { connected } from "node:process";
const db =await mysql.createConnection({

    host:"localhost",
    user:"root",
    password:"Rishv@1819",
    database:"career"

});

console.log("database connected");


export default db;