import express from "express";
import multer from "multer";
import db from "../db.mjs";

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },

  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({
  storage,

  fileFilter: (req, file, cb) => {
    const allowed = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only PDF, DOC and DOCX files are allowed"));
    }
  },
});

router.post("/apply", upload.single("resume"), async (req, res) => {
  try {
    
    const { name, email, phone, country, position, status } = req.body;

    const resume = req.file ? req.file.filename : null;

    const sql = `
      INSERT INTO jobapplicationsform
      (name, email, phone, country, position, status, resume)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      name,
      email,
      phone,
      country,
      position,
      status,
      resume,
    ]);


    return res.status(201).json({
      success: true,
      message: "Application Submitted Successfully",
    });
    console.log("data submited successfully")

  } catch (error) {
    console.error("ERROR:", error);

    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

export default router;