import db from "../config/db.js";

// =======================
// Get All Offers
// =======================
export const getOffers = async (req, res) => {
  try {

    const [rows] = await db.query(`
      SELECT
        offers.*,
        applicantsform.name,
        applicantsform.email,
        applicantsform.position
      FROM offers
      JOIN applicantsform
      ON offers.applicant_id = applicantsform.id
      ORDER BY offers.offer_date DESC
    `);

    res.json(rows);

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message
    });

  }
};


// =======================
// Add Offer
// =======================
export const addOffer = async (req, res) => {

  try {

    const {
      applicant_id,
      offer_date,
      package_amount,
      status,
      offer_letter
    } = req.body;

    // Check Applicant Exists
    const [applicant] = await db.query(
      "SELECT * FROM applicantsform WHERE id=?",
      [applicant_id]
    );

    if (applicant.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Applicant Not Found"
      });
    }

    // Insert Offer
    await db.query(
      `INSERT INTO offers
      (
        applicant_id,
        offer_date,
        package_amount,
        status,
        offer_letter
      )
      VALUES (?,?,?,?,?)`,
      [
        applicant_id,
        offer_date,
        package_amount,
        status,
        offer_letter
      ]
    );

    // Update Applicant Stage
    await db.query(
      "UPDATE applicantsform SET stage=? WHERE id=?",
      ["Offer Sent", applicant_id]
    );

    res.status(201).json({
      success: true,
      message: "Offer Sent Successfully"
    });

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message
    });

  }

};


// =======================
// Update Offer
// =======================
export const updateOffer = async (req, res) => {

  try {

    const { id } = req.params;

    const {
      offer_date,
      package_amount,
      status,
      offer_letter
    } = req.body;

    await db.query(
      `UPDATE offers
      SET
        offer_date=?,
        package_amount=?,
        status=?,
        offer_letter=?
      WHERE id=?`,
      [
        offer_date,
        package_amount,
        status,
        offer_letter,
        id
      ]
    );

    res.json({
      success: true,
      message: "Offer Updated Successfully"
    });

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message
    });

  }

};


// =======================
// Delete Offer
// =======================
export const deleteOffer = async (req, res) => {

  try {

    const { id } = req.params;

    await db.query(
      "DELETE FROM offers WHERE id=?",
      [id]
    );

    res.json({
      success: true,
      message: "Offer Deleted Successfully"
    });

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message
    });

  }

};


// =======================
// Get Offer By ID
// =======================
export const getOfferById = async (req, res) => {

  try {

    const { id } = req.params;

    const [rows] = await db.query(`
      SELECT
        offers.*,
        applicantsform.name,
        applicantsform.email,
        applicantsform.phone,
        applicantsform.country,
        applicantsform.position
      FROM offers
      JOIN applicantsform
      ON offers.applicant_id = applicantsform.id
      WHERE offers.id=?
    `, [id]);

    if (rows.length === 0) {

      return res.status(404).json({
        success: false,
        message: "Offer Not Found"
      });

    }

    res.json(rows[0]);

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message
    });

  }

};