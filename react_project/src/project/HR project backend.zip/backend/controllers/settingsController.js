import db from "../config/db.js";

// =============================
// Get All Settings
// =============================
export const getSettings = async (req, res) => {
    try {

        const [rows] = await db.query("SELECT * FROM settings");

        res.status(200).json(rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching settings",
            error: error.message
        });

    }
};

// =============================
// Get Setting By ID
// =============================
export const getSettingById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM settings WHERE id=?",
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                message: "Setting not found"
            });

        }

        res.status(200).json(rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching setting",
            error: error.message
        });

    }

};

// =============================
// Create Settings
// =============================
export const createSettings = async (req, res) => {

    try {

        const {

            company_name,
            company_email,
            company_phone,
            company_address

        } = req.body;

        const [result] = await db.query(

            `INSERT INTO settings
            (company_name, company_email, company_phone, company_address)
            VALUES (?,?,?,?)`,

            [
                company_name,
                company_email,
                company_phone,
                company_address
            ]

        );

        res.status(201).json({

            message: "Settings created successfully",
            id: result.insertId

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            message: "Error creating settings",
            error: error.message

        });

    }

};

// =============================
// Update Settings
// =============================
export const updateSettings = async (req, res) => {

    try {

        const { id } = req.params;

        const {

            company_name,
            company_email,
            company_phone,
            company_address

        } = req.body;

        await db.query(

            `UPDATE settings
            SET
            company_name=?,
            company_email=?,
            company_phone=?,
            company_address=?
            WHERE id=?`,

            [
                company_name,
                company_email,
                company_phone,
                company_address,
                id
            ]

        );

        res.status(200).json({

            message: "Settings updated successfully"

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            message: "Error updating settings",
            error: error.message

        });

    }

};

// =============================
// Delete Settings
// =============================
export const deleteSettings = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(

            "DELETE FROM settings WHERE id=?",
            [id]

        );

        res.status(200).json({

            message: "Settings deleted successfully"

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            message: "Error deleting settings",
            error: error.message

        });

    }

};

// =============================
// Reset Settings
// =============================
export const resetSettings = async (req, res) => {

    try {

        await db.query("DELETE FROM settings");

        res.status(200).json({

            message: "All settings reset successfully"

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            message: "Error resetting settings",
            error: error.message

        });

    }

};