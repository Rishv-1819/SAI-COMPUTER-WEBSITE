import db from "../config/db.js";

export const getApplicants = async (req, res) => {

    try {

        const [rows] = await db.query(
            "SELECT * FROM applicantsform ORDER BY id DESC"
        );

        res.status(200).json(rows);

    } catch (err) {

        console.log(err);

        res.status(500).json({
            message: err.message
        });

    }

};

export const updateStage = async (req, res) => {

    try {

        const { id } = req.params;

        const { stage } = req.body;

        await db.query(

            "UPDATE applicantsform SET stage=? WHERE id=?",

            [stage, id]

        );

        res.json({

            message: "Stage Updated"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

}
export const deleteApplicant = async (req, res) => {
  try {
    const { id } = req.params;

    await db.query(
      "DELETE FROM applicantsform WHERE id = ?",
      [id]
    );

    res.json({
      success: true,
      message: "Applicant deleted successfully",
    });

  } catch (err) {
    console.log(err);

    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};
export const getApplicantById = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM applicantsform WHERE id = ?",
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: "Applicant not found",
      });
    }

    res.json(rows[0]);

  } catch (err) {
    console.log(err);

    res.status(500).json({
      message: err.message,
    });
  }
};
