import db from "../config/db.js";

// ===============================
// Get All Jobs
// ===============================
export const getJobs = async (req, res) => {

    try {

        const [rows] = await db.query(`
            SELECT *
            FROM job_openings
            ORDER BY id DESC
        `);

        res.json(rows);

    } catch (err) {

        console.log(err);

        res.status(500).json({
            message: err.message
        });

    }

};

// ===============================
// Get Job By Id
// ===============================
export const getJobById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(

            "SELECT * FROM job_openings WHERE id=?",

            [id]

        );

        if (rows.length === 0) {

            return res.status(404).json({

                message: "Job Not Found"

            });

        }

        res.json(rows[0]);

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};

// ===============================
// Create Job
// ===============================
export const createJob = async (req, res) => {

    try {

        const {

            title,

            department,

            description,

            salary_range,

            status

        } = req.body;

        const [result] = await db.query(

            `INSERT INTO job_openings
            (
                title,
                department,
                description,
                salary_range,
                status
            )
            VALUES(?,?,?,?,?)`,

            [

                title,

                department,

                description,

                salary_range,

                status || "draft"

            ]

        );

        res.json({

            success: true,

            id: result.insertId,

            message: "Job Created Successfully"

        });

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};

// ===============================
// Update Job
// ===============================
export const updateJob = async (req, res) => {

    try {

        const { id } = req.params;

        const {

            title,

            department,

            description,

            salary_range,

            status

        } = req.body;

        await db.query(

            `UPDATE job_openings
             SET
             title=?,
             department=?,
             description=?,
             salary_range=?,
             status=?
             WHERE id=?`,

            [

                title,

                department,

                description,

                salary_range,

                status,

                id

            ]

        );

        res.json({

            message: "Job Updated"

        });

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};

// ===============================
// Delete Job
// ===============================
export const deleteJob = async (req, res) => {

    try {

        await db.query(

            "DELETE FROM job_openings WHERE id=?",

            [req.params.id]

        );

        res.json({

            message: "Job Deleted"

        });

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};

// ===============================
// Publish Job
// ===============================
export const publishJob = async (req, res) => {

    try {

        await db.query(

            "UPDATE job_openings SET status='published' WHERE id=?",

            [req.params.id]

        );

        res.json({

            message: "Job Published"

        });

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};

// ===============================
// Close Job
// ===============================
export const closeJob = async (req, res) => {

    try {

        await db.query(

            "UPDATE job_openings SET status='closed' WHERE id=?",

            [req.params.id]

        );

        res.json({

            message: "Job Closed"

        });

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: err.message

        });

    }

};