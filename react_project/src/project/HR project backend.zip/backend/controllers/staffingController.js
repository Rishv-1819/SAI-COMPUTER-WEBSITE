import db from "../config/db.js";

// ==============================
// Get All Staffing Plans
// ==============================
export const getStaffing = async (req, res) => {
    try {

        const [rows] = await db.query(
            "SELECT * FROM staffing_plans ORDER BY created_at DESC"
        );

        res.status(200).json(rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching staffing plans",
            error: error.message,
        });

    }
};

// ==============================
// Get Staffing By ID
// ==============================
export const getStaffingById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM staffing_plans WHERE id=?",
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                message: "Staffing plan not found",
            });

        }

        res.status(200).json(rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching staffing plan",
            error: error.message,
        });

    }

};

// ==============================
// Create Staffing Plan
// ==============================
export const createStaffing = async (req, res) => {

    try {

        const {
            requisition_id,
            role_name,
            department,
            vacancies,
            estimated_cost,
            current_headcount,
            status,
        } = req.body;

        const [result] = await db.query(

            `INSERT INTO  staffing_plans
            (
                requisition_id,
                role_name,
                department,
                vacancies,
                estimated_cost,
                current_headcount,
                status
            )
            VALUES (?,?,?,?,?,?,?)`,

            [
                requisition_id,
                role_name,
                department,
                vacancies,
                estimated_cost || 0,
                current_headcount || 0,
                status || "draft",
            ]

        );

        res.status(201).json({
            message: "Staffing plan created successfully",
            id: result.insertId,
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error creating staffing plan",
            error: error.message,
        });

    }

};

// ==============================
// Update Staffing Plan
// ==============================
export const updateStaffing = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            requisition_id,
            role_name,
            department,
            vacancies,
            estimated_cost,
            current_headcount,
            status,
        } = req.body;

        await db.query(

            `UPDATE staffing_plans
             SET
             requisition_id=?,
             role_name=?,
             department=?,
             vacancies=?,
             estimated_cost=?,
             current_headcount=?,
             status=?
             WHERE id=?`,

            [
                requisition_id,
                role_name,
                department,
                vacancies,
                estimated_cost,
                current_headcount,
                status,
                id,
            ]

        );

        res.status(200).json({
            message: "Staffing plan updated successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error updating staffing plan",
            error: error.message,
        });

    }

};

// ==============================
// Delete Staffing Plan
// ==============================
export const deleteStaffing = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "DELETE FROM staffing_plans WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Staffing plan deleted successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error deleting staffing plan",
            error: error.message,
        });

    }

};

// ==============================
// Activate Staffing Plan
// ==============================
export const activateStaffing = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "UPDATE staffing_plans SET status='active' WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Staffing plan activated successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error activating staffing plan",
            error: error.message,
        });

    }

};

// ==============================
// Close Staffing Plan
// ==============================
export const closeStaffing = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "UPDATE staffing_plans SET status='closed' WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Staffing plan closed successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error closing staffing plan",
            error: error.message,
        });

    }

};