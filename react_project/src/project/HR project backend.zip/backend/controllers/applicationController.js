import db from "../config/db.js";

export const applyJob = async (req, res) => {

    try {

        const {
            name,
            email,
            phone,
            country,
            position,
            status
        } = req.body;
        const stage = "Applied";

        const resume = req.file
            ? req.file.filename
            : null;

        await db.query(

            `INSERT INTO applicantsform
            (
                name,
                email,
                phone,
                country,
                position,
                stage,
                status,
                resume
            )
            VALUES
            (
                ?,?,?,?,?,?,?,?
            )`,

            [
                name,
                email,
                phone,
                country,
                position,
                stage,
                status,
                resume
            ]

        );

        res.status(201).json({

            success: true,

            message: "Application Submitted Successfully"

        });

    }

    catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};