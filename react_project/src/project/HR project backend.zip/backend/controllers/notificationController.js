import { sendEmail } from "../services/emailService.js";

export const sendOfferEmail = async (req, res) => {

    try {

        const {

            email,

            name

        } = req.body;

        await sendEmail(

            email,

            "Job Offer",

            `Congratulations ${name},

Your Job Offer has been released.

Please login to HR Portal.

Regards
HR Team`

        );

        res.json({

            message: "Offer Email Sent"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

};