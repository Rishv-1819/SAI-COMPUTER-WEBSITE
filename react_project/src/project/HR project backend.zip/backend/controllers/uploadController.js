export const uploadResume = async (req, res) => {

    try {

        if (!req.file) {

            return res.status(400).json({

                message: "No File Uploaded"

            });

        }

        res.json({

            message: "Resume Uploaded",

            file: req.file.filename,

            path: `/uploads/${req.file.filename}`

        });

    }

    catch (err) {

        res.status(500).json({

            message: err.message

        });

    }

};