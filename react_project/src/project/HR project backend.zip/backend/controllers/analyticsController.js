import db from "../config/db.js";

export const getAnalytics = async (req, res) => {

    try {

        const analytics = {

            hiring: [

                { month: "Jan", hired: 4 },

                { month: "Feb", hired: 7 },

                { month: "Mar", hired: 5 },

                { month: "Apr", hired: 10 },

                { month: "May", hired: 8 },

                { month: "Jun", hired: 12 }

            ],

            departments: [

                {

                    department: "IT",

                    count: 18

                },

                {

                    department: "HR",

                    count: 6

                },

                {

                    department: "Sales",

                    count: 12

                },

                {

                    department: "Accounts",

                    count: 5

                }

            ],

            funnel: [

                {

                    stage: "Applied",

                    value: 120

                },

                {

                    stage: "Interview",

                    value: 55

                },

                {

                    stage: "Offer",

                    value: 22

                },

                {

                    stage: "Hired",

                    value: 15

                }

            ]

        };

        res.json(analytics);

    }

    catch (err) {

        res.status(500).json(err);

    }

};