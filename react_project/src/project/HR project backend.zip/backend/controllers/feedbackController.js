import db from "../config/db.js";

export const getFeedbacks = async (req, res) => {

    try {

        const [rows] = await db.query(`
            SELECT
            feedback.*,
            applicants.full_name
            FROM feedback
            JOIN interviews
            ON feedback.interview_id = interviews.id
            JOIN applicants
            ON interviews.applicant_id = applicants.id
            ORDER BY feedback.created_at DESC
        `);

        res.json(rows);

    }

    catch (err) {

        res.status(500).json(err);

    }

};

export const addFeedback = async (req, res) => {

    try {

        const {

            interview_id,
            interviewer_name,
            rating,
            skills,
            comments,
            result

        } = req.body;

        await db.query(

            `INSERT INTO feedback
            (
                interview_id,
                interviewer_name,
                rating,
                skills,
                comments,
                result
            )
            VALUES (?,?,?,?,?,?)`,

            [

                interview_id,
                interviewer_name,
                rating,
                skills,
                comments,
                result

            ]

        );

        res.json({

            message: "Feedback Added Successfully"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

};
export const updateFeedback = async (req, res) => {

    try {

        const { id } = req.params;

        const {

            interviewer_name,

            rating,

            skills,

            comments,

            result

        } = req.body;

        await db.query(

            `UPDATE feedback
             SET
             interviewer_name=?,
             rating=?,
             skills=?,
             comments=?,
             result=?
             WHERE id=?`,

            [

                interviewer_name,

                rating,

                skills,

                comments,

                result,

                id

            ]

        );

        res.json({

            message: "Feedback Updated"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

};

export const deleteFeedback = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(

            "DELETE FROM feedback WHERE id=?",

            [id]

        );

        res.json({

            message: "Feedback Deleted"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

};