import db from "../config/db.js";

export const getDashboard = async (req, res) => {

    try {

        const [[jobOpenings]] = await db.query(
            "SELECT COUNT(*) AS total FROM job_openings"
        );

        const [[applicants]] = await db.query(
            "SELECT COUNT(*) AS total FROM applicantsform"
        );

        const [[interviews]] = await db.query(
            "SELECT COUNT(*) AS total FROM interviews"
        );

        const [[offers]] = await db.query(
            "SELECT COUNT(*) AS total FROM offers"
        );

        const [[hired]] = await db.query(
            "SELECT COUNT(*) AS total FROM applicantsform WHERE stage='Hired'"
        );

        res.json({

            totalJobs: jobOpenings.total,

            totalApplicants: applicants.total,

            totalInterviews: interviews.total,

            totalOffers: offers.total,

            totalHired: hired.total

        });

    } catch (err) {

        console.log(err);

        res.status(500).json({

            totalJobs: 0,

            totalApplicants: 0,

            totalInterviews: 0,

            totalOffers: 0,

            totalHired: 0

        });

    }

};