import db from "../config/db.js";

export const getApplicantById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(

            "SELECT * FROM applicants WHERE id=?",
            [id]

        );

        if (rows.length === 0) {

            return res.status(404).json({

                message: "Applicant Not Found"

            });

        }

        res.json(rows[0]);

    }

    catch (err) {

        console.log(err);

        res.status(500).json({

            message: "Server Error"

        });

    }

};