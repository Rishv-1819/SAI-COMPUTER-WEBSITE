import db from "../config/db.js";

// ===============================
// Get All Requisitions
// ===============================
export const getRequisitions = async (req, res) => {
    try {

        const [rows] = await db.query(
            "SELECT * FROM job_requisitions ORDER BY created_at DESC"
        );

        res.status(200).json(rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching requisitions",
            error: error.message,
        });

    }
};

// ===============================
// Get Requisition By ID
// ===============================
export const getRequisitionById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM job_requisitions WHERE id=?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Requisition not found",
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error fetching requisition",
            error: error.message,
        });

    }
};

// ===============================
// Create Requisition
// ===============================
export const createRequisition = async (req, res) => {

    try {

        const {
            title,
            department,
            vacancies,
            priority,
            estimated_cost,
            status,
        } = req.body;

        const [result] = await db.query(
            `INSERT INTO job_requisitions
            (title, department, vacancies, priority, estimated_cost, status)
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                title,
                department,
                vacancies,
                priority || "medium",
                estimated_cost || 0,
                status || "pending",
            ]
        );

        res.status(201).json({
            message: "Requisition created successfully",
            id: result.insertId,
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error creating requisition",
            error: error.message,
        });

    }
};

// ===============================
// Update Requisition
// ===============================
export const updateRequisition = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            title,
            department,
            vacancies,
            priority,
            estimated_cost,
            status,
        } = req.body;

        await db.query(
            `UPDATE job_requisitions
             SET
             title=?,
             department=?,
             vacancies=?,
             priority=?,
             estimated_cost=?,
             status=?
             WHERE id=?`,
            [
                title,
                department,
                vacancies,
                priority,
                estimated_cost,
                status,
                id,
            ]
        );

        res.status(200).json({
            message: "Requisition updated successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error updating requisition",
            error: error.message,
        });

    }
};

// ===============================
// Delete Requisition
// ===============================
export const deleteRequisition = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "DELETE FROM job_requisitions WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Requisition deleted successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error deleting requisition",
            error: error.message,
        });

    }
};

// ===============================
// Approve Requisition
// ===============================
export const approveRequisition = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "UPDATE job_requisitions SET status='approved' WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Requisition approved successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error approving requisition",
            error: error.message,
        });

    }
};

// ===============================
// Reject Requisition
// ===============================
export const rejectRequisition = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "UPDATE job_requisitions SET status='rejected' WHERE id=?",
            [id]
        );

        res.status(200).json({
            message: "Requisition rejected successfully",
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Error rejecting requisition",
            error: error.message,
        });

    }
};