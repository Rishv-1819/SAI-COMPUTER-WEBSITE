import db from "../config/db.js";

// ================= Get All Interviews =================

export const getInterviews = async (req, res) => {
    try {

        const [rows] = await db.query(`
            SELECT
                interviews.*,
                applicantsform.name
            FROM interviews
            JOIN applicantsform
            ON interviews.applicant_id = applicantsform.id
            ORDER BY interviews.interview_date ASC
        `);

        res.json(rows);

    } catch (err) {

        console.log(err);

        res.status(500).json({
            message: err.message
        });

    }
};

// ================= Schedule Interview =================

export const createInterview = async (req, res) => {

    try {

        const {
            applicant_id,
            interviewer_name,
            interview_date,
            mode,
            remarks
        } = req.body;

        await db.query(
            `INSERT INTO interviews
            (
                applicant_id,
                interviewer_name,
                interview_date,
                mode,
                remarks,
                status
            )
            VALUES(?,?,?,?,?,?)`,
            [
                applicant_id,
                interviewer_name,
                interview_date,
                mode,
                remarks,
                "scheduled"
            ]
        );

        await db.query(
            "UPDATE applicantsform SET stage='Interview Scheduled' WHERE id=?",
            [applicant_id]
        );

        res.json({
            success: true,
            message: "Interview Scheduled Successfully"
        });

    } catch (err) {

        console.log(err);

        res.status(500).json(err);

    }

};

// ================= Update =================

export const updateInterview = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            interviewer_name,
            interview_date,
            mode,
            remarks,
            status
        } = req.body;

        await db.query(
            `UPDATE interviews
            SET
            interviewer_name=?,
            interview_date=?,
            mode=?,
            remarks=?,
            status=?
            WHERE id=?`,
            [
                interviewer_name,
                interview_date,
                mode,
                remarks,
                status,
                id
            ]
        );

        res.json({
            message: "Interview Updated"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};

// ================= Delete =================

export const deleteInterview = async (req, res) => {

    try {

        await db.query(
            "DELETE FROM interviews WHERE id=?",
            [req.params.id]
        );

        res.json({
            message: "Interview Deleted"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};