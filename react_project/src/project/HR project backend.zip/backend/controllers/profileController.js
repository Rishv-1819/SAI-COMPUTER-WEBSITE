export const getProfile = async (req, res) => {

    try {

        res.json({

            name: "HR Admin",

            email: "hr@company.com",

            designation: "HR Manager",

            department: "Human Resource"

        });

    }

    catch (err) {

        res.status(500).json(err);

    }

};