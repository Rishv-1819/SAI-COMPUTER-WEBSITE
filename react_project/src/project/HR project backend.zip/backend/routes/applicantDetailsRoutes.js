import express from "express";

import { getApplicantById } from "../controllers/applicantDetailsController.js";

const router = express.Router();

router.get("/:id", getApplicantById);

export default router;