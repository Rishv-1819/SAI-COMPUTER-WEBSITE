import express from "express";

import {
    getRequisitions,
    getRequisitionById,
    createRequisition,
    updateRequisition,
    deleteRequisition,
    approveRequisition,
    rejectRequisition
} from "../controllers/requistionController.js";

const router = express.Router();

router.get("/", getRequisitions);
router.get("/:id", getRequisitionById);

router.post("/", createRequisition);

router.put("/:id", updateRequisition);

router.delete("/:id", deleteRequisition);

router.put("/:id/approve", approveRequisition);

router.put("/:id/reject", rejectRequisition);

export default router;