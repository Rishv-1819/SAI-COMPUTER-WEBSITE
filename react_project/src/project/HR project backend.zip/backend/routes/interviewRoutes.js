import express from "express";

import {

    getInterviews,
    createInterview,
    updateInterview,
    deleteInterview

} from "../controllers/interviewController.js";

const router = express.Router();

router.get("/", getInterviews);

router.post("/", createInterview);

router.put("/:id", updateInterview);

router.delete("/:id", deleteInterview);

export default router;