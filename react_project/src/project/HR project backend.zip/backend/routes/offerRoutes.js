import express from "express";

import { getOffers, addOffer, updateOffer, deleteOffer,getOfferById } from "../controllers/offerController.js";

const router = express.Router();

router.get("/", getOffers);
router.post("/", addOffer);
router.put("/:id",updateOffer);
router.delete("/:id",deleteOffer);
router.get("/:id", getOfferById);

export default router;