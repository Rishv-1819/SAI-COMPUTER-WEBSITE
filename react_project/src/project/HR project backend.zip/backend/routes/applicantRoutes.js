import express from "express";

import {getApplicants ,updateStage, deleteApplicant, getApplicantById } from "../controllers/applicantController.js";

const router = express.Router();

router.get("/", getApplicants);
router.put("/:id",updateStage);
router.delete("/:id", deleteApplicant);
router.get("/:id", getApplicantById);
export default router;


