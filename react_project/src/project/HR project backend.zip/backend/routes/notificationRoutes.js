import express from "express";

import {

    sendOfferEmail

}

    from "../controllers/notificationController.js";

const router = express.Router();

router.post("/offer", sendOfferEmail);

export default router;