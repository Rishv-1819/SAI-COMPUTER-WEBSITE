import express from "express";

import {

    getSettings,
    getSettingById,
    createSettings,
    updateSettings,
    deleteSettings,
    resetSettings

} from "../controllers/settingsController.js";

const router = express.Router();

router.get("/", getSettings);

router.get("/:id", getSettingById);

router.post("/", createSettings);

router.put("/:id", updateSettings);

router.delete("/:id", deleteSettings);

router.post("/reset", resetSettings);

export default router;