import express from "express";

import {getFeedbacks, addFeedback, updateFeedback, deleteFeedback} from "../controllers/feedbackController.js";

const router = express.Router();

router.get("/", getFeedbacks);
router.post("/", addFeedback);
router.put("/:id",updateFeedback);
router.delete("/:id",deleteFeedback);

export default router;