import express from "express";

import {
    getStaffing,
    getStaffingById,
    createStaffing,
    updateStaffing,
    deleteStaffing,
    activateStaffing,
    closeStaffing,
} from "../controllers/staffingController.js";

const router = express.Router();

router.get("/", getStaffing);

router.get("/:id", getStaffingById);

router.post("/", createStaffing);

router.put("/:id", updateStaffing);

router.delete("/:id", deleteStaffing);

router.put("/:id/activate", activateStaffing);

router.put("/:id/close", closeStaffing);

export default router;