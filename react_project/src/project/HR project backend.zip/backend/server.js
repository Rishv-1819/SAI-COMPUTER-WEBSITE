import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import db from "./config/db.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import applicantRoutes from "./routes/applicantRoutes.js";
import applicantDetailsRoutes from "./routes/applicantDetailsRoutes.js";
import interviewRoutes from "./routes/interviewRoutes.js";
import feedbackRoutes from "./routes/feedbackRoutes.js";
import offerRoutes from "./routes/offerRoutes.js";

import analyticsRoutes from "./routes/analyticsRoutes.js";
import notificationRoutes from "./routes/notificationRoutes.js";
import profileRoutes from "./routes/profileRoutes.js";
import uploadRoutes from "./routes/uploadRoutes.js";
import jobRoutes from "./routes/jobRoutes.js";
import requisitionRoutes from "./routes/requistionRoutes.js";
import settingsRoutes from "./routes/settingsRoutes.js";
import staffingRoutes from "./routes/staffingRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import applicationRoutes from "./routes/applicationRoutes.js";



import "./config/db.js";

dotenv.config();

const app = express();

app.use(cors());

app.use(express.json());
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/applicants", applicantRoutes);
app.use("/api/applicants", applicantDetailsRoutes);
app.use("/api/interviews", interviewRoutes);
app.use("/api/feedback",feedbackRoutes);
app.use("/api/offers",offerRoutes);

app.use("/api/analytics",analyticsRoutes);
app.use("/api/notifications",notificationRoutes);
app.use("/api/profile",profileRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/requisitions", requisitionRoutes);
app.use("/api/staffing", staffingRoutes);

app.use("/api/settings", settingsRoutes);
app.use("/api/staffing", staffingRoutes);
app.use("/api/auth", authRoutes);
app.use("/api", applicationRoutes);

app.use("/uploads", express.static("uploads"));

app.get("/", (req, res) => {

    res.json({

        success: true,

        message: "Frappe HR Backend Running"

    });

});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {

    console.log(`Server Running On Port ${PORT}`);

});