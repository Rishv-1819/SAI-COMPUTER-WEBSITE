import transporter from "../config/mailConfig.js";

export const sendEmail = async (

    email,

    subject,

    text

) => {

    await transporter.sendMail({

        from: "HR Recruitment",

        to: email,

        subject,

        text

    });

};